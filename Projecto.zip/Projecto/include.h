#ifndef INCLUDE_H
#define INCLUDE_H

#include "lista.h"
#include "avl.h"
#include "hash.h"
#include "fila.h"
#include "grafo.h"

#endif