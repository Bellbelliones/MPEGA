#include <stdio.h>
#include "include.h"

int main()
{
    start();
    printf("\n\n\n");
    return 0;
}

/*#include <stdio.h>
#include <stdlib.h>

#include "avl.h"

void limparTela();

int main()
{
    Lista tabela[TAM];
    inicializarTabela(tabela);

    int op;

    do
    {
        limparTela();
        printf("==========================================\n");
        printf("          SISTEMA DE VIAGENS MPEGA        \n");
        printf("==========================================\n");
        printf(" [1] Criar Nova Conta (Cadastrar)\n");
        printf(" [2] Entrar no Sistema (Login)\n");
        printf(" [0] Fechar Aplicativo (Sair)\n");
        printf("------------------------------------------\n");
        printf(" Escolha uma opcao: ");

        scanf("%d", &op);

        switch (op)
        {
        case 1:
            cadastrar_usuario(tabela);
            break;
        case 2:
            fazerLogin(tabela);
            break;
        case 0:
            limparTela();
            printf("==========================================\n");
            printf("  Obrigado por usar o MPEGA. Ate a proxima! \n");
            printf("==========================================\n");
            break;
        default:
            printf("\nOpcao invalida! Pressione qualquer tecla para tentar...");
            getchar();
            getchar();
            break;
        }

    } while (op != 0);
    AVL *arvore = criarAVL();

    arvore->raiz = inserirAVL(arvore->raiz, 50);
    arvore->raiz = inserirAVL(arvore->raiz, 30);
    arvore->raiz = inserirAVL(arvore->raiz, 70);
    arvore->raiz = inserirAVL(arvore->raiz, 20);
    arvore->raiz = inserirAVL(arvore->raiz, 40);
    arvore->raiz = inserirAVL(arvore->raiz, 10);
    arvore->raiz = inserirAVL(arvore->raiz, 11);
    printf("Em Ordem:\n");
    posOrdem(arvore->raiz);

    return 0;
}*/